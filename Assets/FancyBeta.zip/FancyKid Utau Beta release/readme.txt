Hello User!
therealvan45 here and i made this voicebank of a roblox exploiter who goes with name "fancykid".
He gave me a permission on creating this so.

here are terms of services

1.Do not reupload it on other websites. Its privated and only can be used by me and fancykid himself,trusted people too.
2.No NSFW(18+) Content with this character, a person is a minor so its not allowed
3.Do not modify this voicebank and DO NOT CREATE A DIFFSINGER FROM ITS FILES.